package com.naufal.myiconapp.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager2.widget.ViewPager2;
import androidx.recyclerview.widget.RecyclerView;

import com.naufal.myiconapp.R;
import com.naufal.myiconapp.adapter.NewsAdapter;
import com.naufal.myiconapp.adapter.PromoSliderAdapter;
import com.naufal.myiconapp.model.News;
import com.naufal.myiconapp.utils.DummyData;

import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private ViewPager2 promoSlider;
    private RecyclerView newsRecycler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        initViews();
        setupPromoSlider();
        setupNews();
    }

    private void initViews() {
        promoSlider = findViewById(R.id.promoSlider);
        newsRecycler = findViewById(R.id.newsRecycler);
    }

    private void setupPromoSlider() {
        PromoSliderAdapter adapter = new PromoSliderAdapter(
                this,
                DummyData.getPromoList()
        );
        promoSlider.setAdapter(adapter);
    }

    private void setupNews() {
        List<News> newsList = DummyData.getNewsList();

        NewsAdapter adapter = new NewsAdapter(this, newsList);
        newsRecycler.setLayoutManager(new LinearLayoutManager(this));
        newsRecycler.setAdapter(adapter);
    }
}
