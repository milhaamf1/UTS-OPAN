package com.naufal.myiconapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.naufal.myiconapp.R;
import com.naufal.myiconapp.model.Promo;

import java.util.List;

public class PromoSliderAdapter extends RecyclerView.Adapter<PromoSliderAdapter.ViewHolder> {

    private Context context;
    private List<Promo> promoList;

    public PromoSliderAdapter(Context context, List<Promo> promoList) {
        this.context = context;
        this.promoList = promoList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_promo_slider, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Promo promo = promoList.get(position);
        holder.imagePromo.setImageResource(promo.getImageResId());
    }

    @Override
    public int getItemCount() {
        return promoList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imagePromo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imagePromo = itemView.findViewById(R.id.imgPromo);
        }
    }
}
