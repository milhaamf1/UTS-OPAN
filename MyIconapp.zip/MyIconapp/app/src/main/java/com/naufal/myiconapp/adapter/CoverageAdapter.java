package com.naufal.myiconapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.naufal.myiconapp.R;
import com.naufal.myiconapp.model.Coverage;

import java.util.List;

public class CoverageAdapter extends RecyclerView.Adapter<CoverageAdapter.ViewHolder> {

    private Context context;
    private List<Coverage> coverageList;

    public CoverageAdapter(Context context, List<Coverage> coverageList) {
        this.context = context;
        this.coverageList = coverageList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.card_coverage, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Coverage item = coverageList.get(position);

        holder.icon.setImageResource(item.getIconResId());
        holder.label.setText(item.getLabel());
    }

    @Override
    public int getItemCount() {
        return coverageList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView icon;
        TextView label;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.coverageIcon);
            label = itemView.findViewById(R.id.coverageDesc);
        }
    }
}
