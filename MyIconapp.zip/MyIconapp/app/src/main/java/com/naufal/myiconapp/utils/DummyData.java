package com.naufal.myiconapp.utils;

import com.naufal.myiconapp.R;
import com.naufal.myiconapp.model.News;
import com.naufal.myiconapp.model.Promo;

import java.util.ArrayList;
import java.util.List;

public class DummyData {

    public static List<News> getNewsList() {
        List<News> list = new ArrayList<>();

        // Pastikan drawable sample_news1, sample_news2, sample_news3 ada di res/drawable
        list.add(new News("Icon+ Tingkatkan Layanan", "Jakarta, 25 Sep 2025", 3902, R.drawable.sample_news1));
        list.add(new News("Ekspansi Jaringan Baru", "Bandung, 20 Sep 2025", 2400, R.drawable.sample_news2));
        list.add(new News("Peningkatan Infrastruktur", "Surabaya, 10 Sep 2025", 1800, R.drawable.sample_news3));

        return list;
    }

    public static List<Promo> getPromoList() {
        List<Promo> list = new ArrayList<>();

        // Pastikan drawable sample_promo1, sample_promo2 ada di res/drawable
        list.add(new Promo(R.drawable.sample_promo, "Diskon Paket A"));

        return list;
    }
}
