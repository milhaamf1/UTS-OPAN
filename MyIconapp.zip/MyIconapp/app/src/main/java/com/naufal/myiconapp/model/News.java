package com.naufal.myiconapp.model;

public class News {

    private String title;
    private String locationDate;
    private int views;
    private int imageRes;

    public News(String title, String locationDate, int views, int imageRes) {
        this.title = title;
        this.locationDate = locationDate;
        this.views = views;
        this.imageRes = imageRes;
    }

    public String getTitle() { return title; }
    public String getLocationDate() { return locationDate; }
    public int getViews() { return views; }
    public int getImageRes() { return imageRes; }
}
