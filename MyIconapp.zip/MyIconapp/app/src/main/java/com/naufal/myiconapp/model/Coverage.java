package com.naufal.myiconapp.model;

public class Coverage {

    private int iconResId;
    private String label;

    public Coverage(int iconResId, String label) {
        this.iconResId = iconResId;
        this.label = label;
    }

    public int getIconResId() {
        return iconResId;
    }

    public String getLabel() {
        return label;
    }
}
